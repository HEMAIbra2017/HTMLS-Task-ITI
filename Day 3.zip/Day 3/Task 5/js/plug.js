
window.onload = function() {
    var a = document.getElementById("myCanvas");
    var ctx = a.getContext("2d");
    var img = document.getElementById("image");
    img.width=a.width;
    img.height=a.height;
    ctx.drawImage(img, 0, 0,a.width,a.height);

   }
