var c = document.getElementById("myCanvas");
var ctx = c.getContext("2d");

var my_gradient = ctx.createLinearGradient(0,0,0,150);
my_gradient.addColorStop(0,  'blue');
my_gradient.addColorStop(0.5, 'white');
my_gradient.addColorStop(0.5, 'green');
my_gradient.addColorStop(1, 'white');

var line = ctx.createLinearGradient(0,90,0, 95);
line.addColorStop(0.5, 'black');
line.addColorStop(1, 'rgba(0, 0, 0, 0)');
ctx.beginPath()
ctx.lineWidth=4
ctx.lineJoin = "bevel"
ctx.moveTo(110,180)
ctx.lineTo(300,180);
ctx.lineTo(300,250);
ctx.stroke()
ctx.closePath()
ctx.beginPath()
ctx.moveTo(110,250)
ctx.lineTo(110,178);
ctx.stroke()
ctx.closePath()

ctx.strokeStyle = line;
ctx.fillStyle = my_gradient;
ctx.fillRect(10, 10, 250, 130);
ctx.strokeRect(50, 50, 50, 50);
 
