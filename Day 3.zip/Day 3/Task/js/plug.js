var mycanvas = document.querySelector('#mycanvas')
var ctx = mycanvas.getContext('2d');
var grd = ctx.createLinearGradient(30, -30, 0, 290);
grd.addColorStop(0, "blue");
grd.addColorStop(1, "white");
ctx.fillStyle = grd;
ctx.fillRect(0, 0, 400, 480);
var grd1 = ctx.createLinearGradient(30, -30, 0, 800);
grd1.addColorStop(0, "green");
grd1.addColorStop(1, "white");
ctx.fillStyle = grd1;
ctx.fillRect(0, 215, 400, 480);
ctx.beginPath()
ctx.lineWidth=4
ctx.lineJoin = "bevel"
ctx.moveTo(110,180)
ctx.lineTo(300,180);
ctx.lineTo(300,250);
ctx.stroke()
ctx.closePath()
ctx.beginPath()
ctx.moveTo(110,250)
ctx.lineTo(110,178);
ctx.stroke()
ctx.closePath()
