var mycanvas = document.querySelector('#mycanvas');
var ctx = mycanvas.getContext('2d');

ctx.beginPath()
var grd = ctx.createLinearGradient(0,350,  290, 50);
grd.addColorStop(0, "blue");
grd.addColorStop(1, "white");
ctx.fillStyle = grd;
ctx.strokeStyle = "white";
ctx.arc(130, 130, 120,0,2*Math.PI);
ctx.stroke()
ctx.fill()
ctx.closePath()

ctx.beginPath()
var grd1 = ctx.createLinearGradient(10,0, 250, 0);
grd1.addColorStop(0, "blue");
grd1.addColorStop(1, "white");
ctx.fillStyle = grd1;
ctx.strokeStyle = "cornflowerblue";
ctx.arc(130, 130, 90,0,2*Math.PI);
ctx.stroke()
ctx.fill()
ctx.closePath()
