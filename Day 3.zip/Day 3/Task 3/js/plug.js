var conelment=document.querySelector("#mycanvas");
var ctx=conelment.getContext("2d");

ctx.beginPath();
ctx.moveTo(200,200);
ctx.lineTo(200,50);
ctx.lineTo(50,200);
ctx.closePath();

ctx.lineWidth=10;
ctx.strokeStyle="black";
ctx.stroke();

ctx.fillStyle = " #ff8080";
 ctx.fill();




 
