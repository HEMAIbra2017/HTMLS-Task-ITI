var displayBtn=document.querySelector('button')
        var mapContainer=document.querySelector('#map')

        displayBtn.addEventListener('click',function(){
        if(navigator.geolocation){

                navigator.geolocation.getCurrentPosition(success,error)
            }
            else{
                mapContainer.innerText = "you need to use another browser for ex: firefox or chrome"
            }
        })

        function success(position){
            console.log(position)
            map.innerText = "position is :("+position.coords.longitude+" , "+position.coords.latitude+").";
            var mapObj = new google.maps.Map(mapContainer,{
                center:{
                    lng:position.coords.longitude,
                    lat:position.coords.latitude
                },
                zoom:18
            })
            var posion = {
                lat: position.coords.latitude,
                lng: position.coords.longitude
            }
            var p = new google.maps.Marker({
                position: posion,
                title: "hi asoom"
            });
            p.setMap(mapObj);

        }

        function error(positionError){
            console.log(positionError)
            var message = ""
            switch(positionError.code){
                case 1:{
                message = "Plz allow me to get your location ."
                    break;
                }
                case 2:{
                    message = "check your configuration"
                    break;
                }
                case 3:{
                    message = "check your connection and try again"
                    break;
                }
                default:{
                    message = "unkown error, reload."
                }
            }
            map.innerText = message
        }
