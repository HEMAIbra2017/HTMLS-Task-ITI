

function filterone()
{

document.getElementById("img").style.filter="saturate(40%)";
}
function filtertwo()
{
    document.getElementById("img").style.filter="opacity(20%)";
}
function filterthree()
{
    document.getElementById("img").style.filter="invert(60%)";
}
function filterfour()
{
    document.getElementById("img").style.filter="sepia(40%)";
}
function filterfive()
{
    document.getElementById("img").style.filter = "grayscale(100%)";
}
